#import <Foundation/Foundation.h>

@interface __NSCFType : NSObject
@end
@interface __NSCFString : NSObject // NSString
@end
@interface __NSCFConstantString : __NSCFString
@end

extern int __CFConstantStringClassReference[];
